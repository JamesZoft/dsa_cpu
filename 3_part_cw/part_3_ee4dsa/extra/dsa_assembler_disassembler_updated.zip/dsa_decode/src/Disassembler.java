import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Disassembler {
	
	public static char[] extractAluStuff(char[] opcode)
	{
		String retVal = "";
		switch(opcode[1])
		{
		case '0' : retVal =  "0000"; break;
		case '1' : retVal =  "0001"; break;
		case '2' : retVal =  "0010"; break;
		case '3' : retVal =  "0011"; break;
		case '4' : retVal =  "0100"; break;
		case '5' : retVal =  "0101"; break;
		case '6' : retVal =  "0110"; break;
		case '7' : retVal =  "0111"; break;
		case '8' : retVal =  "1000"; break;
		case '9' : retVal =  "1001"; break;
		case 'A' : retVal =  "1010"; break;
		case 'B' : retVal =  "1011"; break;
		case 'C' : retVal =  "1100"; break;
		case 'D' : retVal =  "1101"; break;
		case 'E' : retVal =  "1110"; break;
		case 'F' : retVal =  "1111"; break;
		default : break;
		}
		
		
		return retVal.toCharArray();
	}
	
	public static String extractOperator(char[] oper)
	{
		String operS = new String(oper);
		int op = Integer.valueOf(operS, 16);
		String result = "";
		switch(op)
		{
		case 0x01 : result = "=";
		case 0x02 : result = "/=";
		case 0x03 : result = "<";
		case 0x04 : result = "<=";
		case 0x05 : result = ">";
		case 0x06 : result = ">=";
		case 0x07 : result = "=0";
		case 0x08 : result = "/=0";
		default : break;
		}
		return result;
	}
	
	public static void main(String[] args) throws IOException
	{
		File hexFile = new File("hex.txt");
		Scanner scan = new Scanner(hexFile);
		
		File outFile = new File("decoded_hex.txt");
		File outFileForAssembler = new File("assembly.txt");
		if (!outFile.exists()) {
			outFile.createNewFile();
		}
		if (!outFileForAssembler.exists()) {
			outFileForAssembler.createNewFile();
		}
		FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		FileWriter fwForAssembler = new FileWriter(outFileForAssembler.getAbsoluteFile());
		BufferedWriter bwForAssembler = new BufferedWriter(fwForAssembler);
		
		while(scan.hasNext())
		{
			String s = scan.nextLine();
			String out = "";
			if(s.charAt(0) == '0' && s.charAt(1) == '0' && s.charAt(s.length() - 1) == '0' && s.charAt(s.length() - 2) == '0')
			{
				out += "IUC";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '1')
			{
				out += "HUC";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '2')
			{
				out += "BUC " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '3')
			{
				out += "BIC " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '4')
			{
				out += "SETO " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '5')
			{
				out += "TSTI " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '6')
			{
				out += "BSR " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '7')
			{
				out += "RSR";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '8')
			{
				out += "RIR";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '9')
			{
				out += "SEI";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'A')
			{
				out += "CLI";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'B')
			{
				out += "MTR " +  s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) +  " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'C')
			{
				out += "RTM " + s.charAt(2) + s.charAt(3) + " " +  s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'D')
			{
				out += "IMTR " + s.charAt(2) + s.charAt(3) + " " +  s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7) ;
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'E')
			{
				out += "RTIM " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'F')
			{
				out += "PSHR " + s.charAt(2) + s.charAt(3);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '0')
			{
				out += "POPR " + s.charAt(2) + s.charAt(3);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '1')
			{
				out += "RTIO " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + "00";
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '2')
			{
				out += "IOTR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + "00";
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '3')
			{
				out += "LDLR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '4')
			{
				out += "LDUR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '5')
			{
				out += "ANDR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7) ;
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '6')
			{
				out += "ORR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '7')
			{
				out += "XORR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '8')
			{
				out += "SRLR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '9')
			{
				out += "SLLR " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == 'A')
			{
				out += "CMPU " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == 'B')
			{
				out += "CMPS " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) + s.charAt(5) + " " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '2' && (s.charAt(1) >= '0' && s.charAt(1) <= '7'))
			{
				char[] aluStuff = extractAluStuff(new char[]{s.charAt(0), s.charAt(1)});
				out += "ALUU " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) 
					+ s.charAt(5) + " " + s.charAt(6) + s.charAt(7) + " " + aluStuff[1] 
								+ " " + aluStuff[2] + " " + aluStuff[3];
			}
			else if(s.charAt(0) == '2' && (s.charAt(1) >= '8' && s.charAt(1) <= 'F'))
			{
				char[] aluStuff = extractAluStuff(new char[]{s.charAt(0), s.charAt(1)});
				out += "ALUS " + s.charAt(2) + s.charAt(3) + " " + s.charAt(4) 
					+ s.charAt(5) + " " + s.charAt(6) + s.charAt(7) + " " + aluStuff[1] 
								+ " " + aluStuff[2] + " " + aluStuff[3];
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '0' && (!s.equals("00000000")))
			{
				out += s;
			}
			bwForAssembler.write(out + "\n");
			bw.write(out + "\n");
		}
		bw.flush();
		bw.close();
		bwForAssembler.flush();
		bwForAssembler.close();
		System.out.println("Assembly written out to assembly.txt and decoded_hex.txt.");
	}

}
