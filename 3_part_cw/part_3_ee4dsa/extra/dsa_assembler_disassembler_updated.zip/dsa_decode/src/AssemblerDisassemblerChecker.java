import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class AssemblerDisassemblerChecker {
	
	public static void main(String[] args) throws FileNotFoundException
	{
		File hex = new File("hex.txt");
		File assembledHex = new File("coded_hex.txt");
		Scanner scan1 = new Scanner(hex);
		Scanner scan2 = new Scanner(assembledHex);
		String scan1L;
		String scan2L;
		int incorrectLines = 0;
		while(scan1.hasNext() && scan2.hasNext())
		{
			scan1L = scan1.nextLine();
			scan2L = scan2.nextLine();
			if(!scan1L.equals(scan2L))
			{
				System.out.println("hex line: " + scan1L);
				System.out.println("codedhex line: " + scan2L);
				incorrectLines ++;
			}
		}
		if(incorrectLines == 0)
			System.out.println("No errors in assembler or disassembler - re-hex'd code is exactly the same as given hex file!");
		
	}

}
