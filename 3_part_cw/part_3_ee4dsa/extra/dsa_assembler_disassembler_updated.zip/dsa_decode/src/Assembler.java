import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import java.util.HashMap;
import java.util.Scanner;


public class Assembler {

	private static int programCounterLength = 6;
		
	private String convertAluStuff(String[] flags, String offset)
	{
		String flagsS = "";
		for(String s : flags)
		{
			flagsS += s;
		}
		int hexValue = 0x00 + Integer.parseInt(flagsS, 2) + Integer.parseInt(offset, 16);
		String s = Integer.toString(hexValue, 16);
		return s.toUpperCase();
	}

	private String convertInstruction(String instruction)
	{
		char[] binaryAndMask = new char[8];
		char[] binaryXorMask = new char[8];
		for(int i = 0; i < instruction.length(); i++)
		{

			if(instruction.charAt(i) == '0')
			{
				binaryAndMask[i] = '0';
				binaryXorMask[i] = '0';
			}
			else if(instruction.charAt(i) == '1')
			{
				binaryAndMask[i] = '1';
				binaryXorMask[i] = '1';
			}
			else if(instruction.charAt(i) == 'x')
			{
				binaryAndMask[i] = '1';
				binaryXorMask[i] = '0';
			}

		}
		String andMask = new String(binaryAndMask);
		String xorMask = new String(binaryXorMask);
		String hexAnd = Integer.toHexString(Integer.parseInt(andMask, 2));
		if(hexAnd.length() == 1)
			hexAnd = "0" + hexAnd;
		String hexXor = Integer.toHexString(Integer.parseInt(xorMask, 2));
		if(hexXor.length() == 1)
			hexXor = "0" + hexXor;

		return (hexAnd + hexXor);
	}

	public void assemble(File f) throws IOException
	{
		Scanner s = new Scanner(f);

		int lineNumber = 0;
		
		File outFile = new File("coded_hex.txt");
		if (!outFile.exists()) {
			outFile.createNewFile();
		}
		FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		
		while(s.hasNext())
		{
			String out = "";
			String next = s.nextLine();
			lineNumber++;
			
			InvalidInputException iie = new InvalidInputException("Invalid assembly on line " + lineNumber);
			
			String[] instruction = next.split(" ");
			if(instruction[0].contains("//") || instruction[0].contains("#")) //If line is a comment
			{
				continue;
			}
			try{
				
				
				if(instruction[0].equalsIgnoreCase("IUC")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "00000000";
				}

				else if(instruction[0].equalsIgnoreCase("HUC")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "01000000";
				}

				else if(instruction[0].equalsIgnoreCase("BUC") || instruction[0].equalsIgnoreCase("JMP")) {
					if(instruction[1].length() != programCounterLength)
						throw iie;
					else
						out = "02" + instruction[1];

				}

				else if(instruction[0].equalsIgnoreCase("BIC")) {
					if(instruction[1].length() != programCounterLength)
						throw iie;
					else
						out = "03" + instruction[1];
				}

				else if(instruction[0].equalsIgnoreCase("SETO")) {
					if(instruction[1].equalsIgnoreCase("port") && instruction[3].matches("[01x]{8}") && (instruction[1].equalsIgnoreCase("00") == true || instruction[1].equalsIgnoreCase("01") == true) )
						out = "04" + instruction[2] + convertInstruction(instruction[3]);
					else if( (instruction[1].equalsIgnoreCase("00") == true || instruction[1].equalsIgnoreCase("01") == true) && instruction[2].length() == 2 && instruction[3].length() == 2)
						out = "04" + instruction[1] + instruction[2] + instruction[3];
					else
						throw iie;
				}

				else if(instruction[0].equalsIgnoreCase("TSTI")) {
					if(instruction[2].equalsIgnoreCase("00") && instruction[1].equalsIgnoreCase("port") && instruction[3].matches("[01x]{8}"))
						out = "05" + instruction[2] + convertInstruction(instruction[3]);
					else if( (instruction[1].equalsIgnoreCase("00") == true || instruction[1].equalsIgnoreCase("01") == true) && instruction[2].length() == 2 && instruction[3].length() == 2)
						out = "05" + instruction[1] + instruction[2] + instruction[3];
					else if(instruction[1].equalsIgnoreCase("01"))
						out = "05" + instruction[1] + instruction[2] + instruction[3];
					else
						throw iie;
				}
				
				else if(instruction[0].equalsIgnoreCase("BSR"))
				{
					if(instruction[1].length() != programCounterLength)
						throw iie;
					else
						out = "06" + instruction[1];
				}
				
				else if(instruction[0].equalsIgnoreCase("RSR")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "07000000";
				}
				
				else if(instruction[0].equalsIgnoreCase("RIR")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "08000000";
				}
				else if(instruction[0].equalsIgnoreCase("SEI")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "09000000";
				}
				else if(instruction[0].equalsIgnoreCase("CLI")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "0A000000";
				}
				else if(instruction[0].equalsIgnoreCase("MTR")) {
					if(instruction.length != 3)
					{
						System.out.println("inst: mtr");
						throw iie;						
					}
					else
						out = "0B" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("RTM")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "0C" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("IMTR")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "0D" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("RTIM")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "0E" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("PSHR")) {
					if(instruction.length != 2)
						throw iie;
					else
						out = "0F" + instruction[1] + "0000";
				}
				else if(instruction[0].equalsIgnoreCase("POPR")) {
					if(instruction.length != 2)
						throw iie;
					else
						out = "10" + instruction[1] + "0000";
				}
				else if(instruction[0].equalsIgnoreCase("RTIO")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "11" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("IOTR")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "12" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("LDLR")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "13" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("LDUR")) {
					if(instruction.length != 3)
						throw iie;
					else
						out = "14" + instruction[1] + instruction[2];
				}
				else if(instruction[0].equalsIgnoreCase("ANDR")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "15" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("ORR")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "16" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("XORR")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = "17" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("SRLR")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "18" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("SLLR")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "19" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("CMPU")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "1A" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("CMPS")) {
					if(instruction.length != 4)
						throw iie;
					else
						out = "1B" + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("ALUU")) {
					if(instruction.length != 7)
						throw iie;
					else
						out = "2" + convertAluStuff(new String[]{instruction[4], instruction[5], instruction[6]}, "0") + instruction[1] + instruction[2] + instruction[3];
				}
				else if(instruction[0].equalsIgnoreCase("ALUS")) {
					if(instruction.length != 7)
						throw iie;
					else
						out = "2" + convertAluStuff(new String[]{instruction[4], instruction[5], instruction[6]}, "8") + instruction[1] + instruction[2] + instruction[3];
				}
				else if(!instruction[instruction.length - 1].equals("0") && !instruction[0].equalsIgnoreCase("IUC")) {
					if(instruction.length != 1)
						throw iie;
					else
						out = next;
				}
				bw.write(out + "\n");
				
			}
			catch (InvalidInputException e) {
				e.printStackTrace();
			}
		}
		bw.flush();
		bw.close();
		System.out.println("Hex written out to coded_hex.txt - try running the AssemblerDisassemblerChecker to see if the given hex file and" +
				" the generated one are the same!");
	}

	public static void main(String[] args) throws IOException
	{
		Assembler a = new Assembler();
		try {
			a.assemble(new File("assembly.txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}


}
