import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DisassemblerAndCommenter {
	
	public static char[] extractAluStuff(char[] opcode)
	{
		String retVal = "";
		switch(opcode[1])
		{
		case '0' : retVal =  "0000"; break;
		case '1' : retVal =  "0001"; break;
		case '2' : retVal =  "0010"; break;
		case '3' : retVal =  "0011"; break;
		case '4' : retVal =  "0100"; break;
		case '5' : retVal =  "0101"; break;
		case '6' : retVal =  "0110"; break;
		case '7' : retVal =  "0111"; break;
		case '8' : retVal =  "1000"; break;
		case '9' : retVal =  "1001"; break;
		case 'A' : retVal =  "1010"; break;
		case 'B' : retVal =  "1011"; break;
		case 'C' : retVal =  "1100"; break;
		case 'D' : retVal =  "1101"; break;
		case 'E' : retVal =  "1110"; break;
		case 'F' : retVal =  "1111"; break;
		default : break;
		}
		
		
		return retVal.toCharArray();
	}
	
	public static String extractOperator(char[] oper)
	{
		String operS = new String(oper);
		String result = "";
		switch(operS)
		{
		case "00" : result = "="; break;
		case "01" : result = "/="; break;
		case "02" : result = "<"; break;
		case "03" : result = "<="; break;
		case "04" : result = ">"; break;
		case "05" : result = ">="; break;
		case "06" : result = "=0"; break;
		case "07" : result = "/=0"; break;
		default : break;
		}
		return result;
	}
		
	public static void main(String[] args) throws IOException
	{
		File hexFile = new File("hex.txt");
		Scanner scan = new Scanner(hexFile);
		
		File outFile = new File("decoded_commented_hex.txt");
		if (!outFile.exists()) {
			outFile.createNewFile();
		}
		FileWriter fw = new FileWriter(outFile.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		
		while(scan.hasNext())
		{
			String s = scan.nextLine();
			String out = "";
			
			if(s.equals("00000000"))
			{
				out += "IUC \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Increment unconditionally or unused RAM data";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '1')
			{
				out += "HUC \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Hold unconditionally";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '2')
			{
				out += "BUC|" + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7) + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t  || Branch unconditionally to address " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '3')
			{
				out += "BIC|" + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7)+ " \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Increment or branch conditionally to address " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '4')
			{
				out += "SET0" + "|port:" + s.charAt(2) + s.charAt(3) + "|anded with:" + s.charAt(4) + s.charAt(5) + "|or'd with:" + s.charAt(6) + s.charAt(7) + "	|| Specify port " + s.charAt(2) + s.charAt(3) + ", AND with " + s.charAt(4) + s.charAt(5) + ", OR with " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '5')
			{
				out += "TSTI" + "|port:" + s.charAt(2) + s.charAt(3) + "|anded with:" + s.charAt(4) + s.charAt(5) + "|or'd with:" + s.charAt(6) + s.charAt(7) + "	|| Test input port " + s.charAt(2) + s.charAt(3) + ", AND with " + s.charAt(4) + s.charAt(5) + ", OR with " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '6')
			{
				out += "BSR|" + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7) + " \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Branch to subroutine at address " + s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '7')
			{
				out += "RSR \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Return from subroutine";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '8')
			{
				out += "RIR \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Return from interrupt";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '9')
			{
				out += "SEI \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Set interrupt enable flag";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'A')
			{
				out += "CLI \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Clear interrupt enable flag";
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'B')
			{
				out += "MTR R[A] = RAM[addr] \t\t\t\t\t\t\t\t\t\t|| Memory at " +  
							s.charAt(2) + s.charAt(3) + s.charAt(4) + s.charAt(5) +  " to register " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'C')
			{
				out += "RTM RAM[addr] = R[A] \t\t\t\t\t\t\t\t\t\t|| Register at " + s.charAt(2) + s.charAt(3) + " to memory at " + 
						s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'D')
			{
				out += "IMTR R[A] = RAM[R[B] + R[C]] \t\t\t\t\t\t|| Indexed memory at " + s.charAt(2) + s.charAt(3) + s.charAt(4) + 
						s.charAt(5) + " to register at " + s.charAt(6) + s.charAt(7) ;
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'E')
			{
				out += "RTIM RAM[R[A] + R[B]] = R[C] \t\t\t\t\t\t|| Register at " + s.charAt(2) + s.charAt(3) + " to indexed memory at " + 
						s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == 'F')
			{
				out += "PSHR R[A] \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Push the value of register " + s.charAt(2) + s.charAt(3) + 
						" onto the stack";
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '0')
			{
				out += "POPR R[A] \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t|| Pop to register " + s.charAt(2) + s.charAt(3);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '1')
			{
				out += "RTIO OUT[port] = R[A] \t\t\t\t\t\t\t\t\t|| Register at " + s.charAt(4) + s.charAt(5) + 
						" to IO out at port " + s.charAt(2) + s.charAt(3);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '2')
			{
				out += "IOTR R[A] = IN[port] \t\t\t\t\t\t\t\t\t\t|| IO in at port " + s.charAt(4) + s.charAt(5) + 
						" to register at " + s.charAt(2) + s.charAt(3);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '3')
			{
				out += "LDLR R[A](15 downto 0) = value \t\t\t\t\t|| Load lower 15 bits of register " + s.charAt(2) 
						+ s.charAt(3) + " with the value " + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '4')
			{
				out += "LDUR R[A](31 downto 16) = value || Load top 15 bits of register " + s.charAt(2) + s.charAt(3) 
						+ " with the value " + s.charAt(4) + s.charAt(5) + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '5')
			{
				out += "ANDR R[A] = R[B] and R[C] || AND register " + s.charAt(2) + s.charAt(3) + " with register " 
							+ s.charAt(4) + s.charAt(5) + " store in register " + s.charAt(6) + s.charAt(7) ;
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '6')
			{
				out += "ORR R[A] = R[B] or R[C] || OR register " + s.charAt(2) + s.charAt(3) + " with register " 
							+ s.charAt(4) + s.charAt(5) + " store in register " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '7')
			{
				out += "XORR R[A] = R[B] xor R[C] || XOR register " + s.charAt(2) + s.charAt(3) + " with register " 
							+ s.charAt(4) + s.charAt(5) + " store in register " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '8')
			{
				out += "SRLR R[A] = R[B] slr C \t\t\t\t\t\t\t\t\t|| Shift right logical register " + s.charAt(2) + s.charAt(3) 
						+ " with " + s.charAt(4) + s.charAt(5) + "store in register " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == '9')
			{
				out += "SLLR R[A] = R[B] slr C \t\t\t\t\t\t\t\t\t|| Shift left logical register " + s.charAt(2) + s.charAt(3) 
						+ " with " + s.charAt(4) + s.charAt(5) + "store in register " + s.charAt(6) + s.charAt(7);
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == 'A')
			{
				String operStuff = extractOperator(new char[]{s.charAt(2), s.charAt(3)});
				out += "CMPU R[A] flag{=,/=,<,<=,>,>=,=0,/=0} R[B] || Compare unsigned register at " + s.charAt(4) + s.charAt(5) 
						+ " with register at " + s.charAt(6) + s.charAt(7) + "using operator: " + operStuff;
			}
			else if(s.charAt(0) == '1' && s.charAt(1) == 'B')
			{
				String operStuff = extractOperator(new char[]{s.charAt(2), s.charAt(3)});
				out += "CMPS R[A] flag{=,/=,<,<=,>,>=,=0,/=0} R[B] || Compare signed register at " + s.charAt(4) + s.charAt(5) 
						+ " with register at " + s.charAt(6) + s.charAt(7) + "using operator: " + operStuff;
			}
			else if(s.charAt(0) == '2' && (s.charAt(1) >= '0' && s.charAt(1) <= '7'))
			{
				char[] aluStuff = extractAluStuff(new char[]{s.charAt(0), s.charAt(1)});
				out += "ALUU || ALU unsigned using register at " + s.charAt(4) + s.charAt(5) + " with register at " + s.charAt(6) 
						+ s.charAt(7) + " and store in register " + s.charAt(2) + s.charAt(3) + " complement R[B]: " + aluStuff[1] 
								+ " complement R[C]: " + aluStuff[2] + " carry flag: " + aluStuff[3];
			}
			else if(s.charAt(0) == '2' && (s.charAt(1) >= '8' && s.charAt(1) <= 'F'))
			{
				char[] aluStuff = extractAluStuff(new char[]{s.charAt(0), s.charAt(1)});
				out += "ALUS || ALU signed using register at " + s.charAt(4) + s.charAt(5) + " with register at " + s.charAt(6) 
						+ s.charAt(7) + " and store in register " + s.charAt(2) + s.charAt(3) + " complement R[B]: " + aluStuff[1] 
								+ " complement R[C]: " + aluStuff[2] + " carry flag: " + aluStuff[3];
			}
			else if(s.charAt(0) == '0' && s.charAt(1) == '0' && (!s.equals("00000000")))
			{
				
				out += "RAM data: " + s;
			}
			
			bw.write(out + "\n");
			
		}
		bw.flush();
		bw.close();
		
	}

}
