This code must be run with Java 1.7 and above. To run this with java 7 (at least on my install), do:

/usr/lib/jvm/java-7-openjdk-i386/bin/java <class>

e.g.: /usr/lib/jvm/java-7-openjdk-i386/bin/java Disassembler

All the files will be written to /bin, with textual output on the console.

Alternatively, you can just open this project in Eclipse (version Indigo was used, not tested on other versions and run the classes.
